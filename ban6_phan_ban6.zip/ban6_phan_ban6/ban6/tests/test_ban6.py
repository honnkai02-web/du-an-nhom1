"""
Test phần Bạn 6.  Chạy:  python tests/test_ban6.py   (hoặc: pytest tests -q)
Toàn bộ dùng dữ liệu giả, chạy < 1 phút, không cần file của bạn khác.
"""
import os
import sys
import tempfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules import model_optimizer as mo  # noqa: E402
from tools.make_fake_dataset import make_fake_pe_dataset  # noqa: E402


def _csv(df, d, name="d.csv"):
    p = os.path.join(d, name)
    df.to_csv(p, index=False)
    return p


def test_fake_dataset_is_imbalanced():
    df = make_fake_pe_dataset(1000, 0.08)
    assert abs(df.label.mean() - 0.08) < 0.01 and df.isna().sum().sum() == 0


def test_evaluate_known_confusion():
    y = [0, 0, 0, 0, 1, 1, 1, 1]
    p = [0.1, 0.2, 0.6, 0.3, 0.9, 0.8, 0.4, 0.7]       # 1 FP, 1 FN
    m = mo.evaluate(y, p, 0.5)
    assert (m["tn"], m["fp"], m["fn"], m["tp"]) == (3, 1, 1, 3)
    assert m["fpr"] == 0.25 and m["recall"] == 0.75 and m["accuracy"] == 0.75


def test_evaluate_handles_no_positive_predictions():
    m = mo.evaluate([0, 1, 0, 1], [0.1, 0.2, 0.1, 0.3], 0.5)
    assert m["precision"] == 0.0 and m["recall"] == 0.0 and m["fpr"] == 0.0


def test_resample_balances_and_only_changes_train():
    rng = np.random.RandomState(0)
    X = rng.randn(200, 4)
    y = np.array([1] * 20 + [0] * 180)
    for st in ("oversample", "smote"):
        X2, y2 = mo.resample(X, y, st)
        assert (y2 == 1).sum() == (y2 == 0).sum() == 180
    X3, y3 = mo.resample(X, y, "undersample")
    assert (y3 == 1).sum() == (y3 == 0).sum() == 20
    X4, y4 = mo.resample(X, y, "none")
    assert X4.shape == X.shape


def test_smote_points_lie_between_minority_samples():
    rng = np.random.RandomState(1)
    X = np.vstack([rng.randn(100, 2) + 10, rng.randn(8, 2)])   # thiểu số quanh (0,0)
    y = np.array([0] * 100 + [1] * 8)
    X2, y2 = mo.resample(X, y, "smote")
    synth = X2[len(X):]
    assert synth.max() <= X[y == 1].max() + 1e-9 and synth.min() >= X[y == 1].min() - 1e-9


def test_choose_threshold_respects_fpr():
    rng = np.random.RandomState(0)
    y = np.array([0] * 500 + [1] * 100)
    p = np.concatenate([rng.beta(2, 8, 500), rng.beta(6, 3, 100)])
    t = mo.choose_threshold(y, p, 0.01)
    assert mo.evaluate(y, p, t)["fpr"] <= 0.01


def test_label_parsing_and_id_columns():
    with tempfile.TemporaryDirectory() as d:
        df = make_fake_pe_dataset(200, 0.2)
        df["label"] = df["label"].map({0: "clean", 1: "malware"})
        df["md5"] = "abc"
        X, y, names = mo.load_dataset(_csv(df, d))
        assert set(y) == {0, 1} and "md5" not in X.columns and "filename" not in X.columns
        assert names[0].startswith("fake_")


def test_merge_two_csvs_by_filename():
    with tempfile.TemporaryDirectory() as d:
        a = make_fake_pe_dataset(150, 0.3)
        b = pd.DataFrame({"filename": a.filename, "label": a.label,
                          "hash_1": np.arange(150), "hash_2": np.arange(150) % 7})
        X, y, _ = mo.load_dataset([_csv(a, d, "a.csv"), _csv(b, d, "b.csv")])
        assert "hash_1" in X.columns and "num_sections" in X.columns and len(y) == 150


def test_single_class_raises():
    with tempfile.TemporaryDirectory() as d:
        df = make_fake_pe_dataset(50, 0.2)
        df["label"] = 0
        try:
            mo.load_dataset(_csv(df, d))
        except ValueError:
            return
        raise AssertionError("phải báo lỗi khi chỉ có 1 lớp")


def test_end_to_end_and_bundle_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        df = make_fake_pe_dataset(600, 0.1, difficulty=1.0, seed=3)
        res = mo.run_pipeline(_csv(df, d), out_dir=d, n_iter=3, cv=3, target_fpr=0.02, verbose=False)
        m = res["metrics_final"]
        assert m["n"] == res["n_test"] and 0 <= m["fpr"] <= 1 and m["recall"] > 0.5
        for k in ("model", "metrics_json", "report_md", "strategy_csv", "plot"):
            assert os.path.exists(res["saved"][k]), k
        b = mo.load_bundle(res["saved"]["model"])
        out = mo.predict_bundle(b, df.drop(columns=["label"]).head(20))   # có cột thừa 'filename'
        assert len(out) == 20 and set(out.verdict) <= {"Clean", "Malware"}
        # thiếu cột / dict một file vẫn chạy
        one = mo.predict_bundle(b, {"num_sections": 6, "avg_section_entropy": 7.4})
        assert len(one) == 1


def test_split_has_no_leakage():
    """Tách train/test phân tầng và không trùng chỉ số (resample chỉ chạy trên train)."""
    df = make_fake_pe_dataset(300, 0.1, seed=5)
    y = df.label
    from sklearn.model_selection import train_test_split
    tr, te = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=42)
    assert not set(tr) & set(te)
    assert abs(y.iloc[tr].mean() - y.iloc[te].mean()) < 0.02     # phân tầng


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    bad = 0
    for f in fns:
        try:
            f()
            print(f"PASS  {f.__name__}")
        except Exception as e:  # noqa
            bad += 1
            print(f"FAIL  {f.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(fns) - bad}/{len(fns)} test đạt")
    sys.exit(1 if bad else 0)
