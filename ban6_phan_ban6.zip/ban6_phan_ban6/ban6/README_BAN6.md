# Phần Bạn 6 – Tối ưu mô hình & đánh giá

Đầu vào: file CSV đặc trưng (cột `label`: 0 = sạch, 1 = mã độc, hoặc chữ clean/malware).
Đầu ra: mô hình đã tối ưu `models/ban6_best_model.joblib` + báo cáo trong `reports/`.

## Cài đặt (Ubuntu / Linux)
    sudo apt update && sudo apt install -y python3 python3-venv python3-pip
    cd ban6
    python3 -m venv venv
    source venv/bin/activate
    pip install numpy pandas scikit-learn joblib matplotlib
    pip install xgboost            # tùy chọn; không cài được thì bỏ qua, code tự dùng mô hình thay thế
Mỗi lần mở terminal mới: `cd ban6 && source venv/bin/activate` rồi mới chạy lệnh.
Windows: `python -m venv venv`, `venv\Scripts\activate`, rồi cùng lệnh `pip install` ở trên.

## Chạy với dữ liệu THẬT (quan trọng)
    python run_ban6_demo.py --csv dataset_pe.csv
    python run_ban6_demo.py --csv dataset_pe.csv dataset_ngram_features.csv    # ghép PE + N-gram theo cột filename
Luôn có `--csv`. Nếu bỏ `--csv`, chương trình sẽ tự sinh DỮ LIỆU GIẢ (dòng đầu in "Dùng dữ liệu GIẢ")
và ghi đè mô hình/báo cáo bằng kết quả giả. Thấy dòng đó mà đang làm dữ liệu thật thì chạy lại có `--csv`.

## Chạy thử nhanh bằng dữ liệu giả (chỉ để kiểm tra code, KHÔNG dùng số liệu này để báo cáo)
    python tests/test_ban6.py        # 11 test
    python run_ban6_demo.py          # dữ liệu giả lệch 92/8
Dữ liệu giả không ảnh hưởng dữ liệu thật: khi có `--csv`, chương trình chỉ đọc đúng file được chỉ định.

## Gộp vào repo
Chỉ THÊM file, không sửa file của ai:
- `modules/model_optimizer.py`   (file chính, bắt buộc)
- `tools/make_fake_dataset.py`, `tools/scan_exe.py` (tùy chọn), `tests/test_ban6.py`, `run_ban6_demo.py`, `README_BAN6.md`
- Không ghi đè `modules/__init__.py` của repo. Thêm `matplotlib` vào requirements.txt nếu thiếu (xgboost tùy chọn).
- Không đưa lên repo: `data/`, `models/`, `reports/` sinh từ dữ liệu giả. Nên thêm 3 thư mục này vào `.gitignore`.

## Cho Bạn 1 gọi trong main.py / app.py
    from modules.model_optimizer import load_bundle, predict_bundle
    bundle = load_bundle("models/ban6_best_model.joblib")
    out = predict_bundle(bundle, features_dict_or_df)   # proba_malware, prediction, verdict
Mô hình chỉ có sau khi chạy với CSV thật. Tên cột đặc trưng lúc dự đoán phải trùng tên cột trong CSV đã train.

